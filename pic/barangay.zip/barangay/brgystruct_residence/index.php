<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>781 Zone 85</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../pic/brgy_logo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
    href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&family=Roboto:wght@500;700&display=swap"
    rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style type="text/css">
     #hero {
      background-repeat: no-repeat;
      animation: carousel 1000s linear infinite;
  }

  @keyframes carousel {
      0%, 100% {
        background-position: 0 0;
    }
    25% {
        background-position: 100% 0;
    }
    50% {
        background-position: 200% 0;
    }
    75% {
        background-position: 300% 0;
    }
}

</style>
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner"
    class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
    <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
</div>
<!-- Spinner End -->


<!-- Topbar Start -->
    <!-- <div class="container-fluid bg-primary text-white d-none d-lg-flex">
        <div class="container py-3">
            <div class="d-flex align-items-center">
                <a href="index.php">
                    <h2 class="text-white fw-bold m-0">781 Zone 85</h2>
                </a>
            </div>
        </div>
    </div> -->
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid bg-dark sticky-top">
        <div class="container bg-transparent">
            <nav class="navbar navbar-expand-lg bg-transparent navbar-light p-lg-0">
                <button type="button" class="navbar-toggler me-0" data-bs-toggle="collapse"
                data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ">

                    <a href="index.php" class="nav-item nav-link active " >Home</a>
                    <a href="profile.php" class="nav-item nav-link text-white" >Profile</a>
                    <a href="certificate.php" class="nav-item nav-link text-white">My Certificate</a>
                    <a href="residentreports.php" class="nav-item nav-link text-white">Residents Reports</a>
                     <a href="about.php" class="nav-item nav-link text-white" >About us</a>
                </div>
                <div class="ms-auto d-none d-lg-block">
                    <a href="../login/index.php" class="btn btn-danger rounded-pill py-2 px-3">Log Out</a>
                </div> 
            </div>
        </nav>
    </div>
</div>
<!-- Navbar End -->

<div class="container-fluid px-0 mb-5">
    <section id="hero" class="d-flex align-items-center" style=" max-width: 100%;
    height: auto;
    height: calc(110vh - 110px);
    background: url('../pic/whole.png') top center;
    background-size: cover;
    position: relative;">
    <div class="container position-relative" data-aos="fade-up" data-aos-delay="500" >
        <img src="../pic/brgy_logo.png" class="img-thumbnail rounded-circle mx-auto d-block" alt="logo" width="200" height="200" style="opacity: .8;">
        <h1 style="font-size: 3rem;">Welcome to Brgy. 781 Zone 85 </h1>
        <div class="text-center">
            <a href="add_book.php" class="btn-get-started scrollto btn-lg" style="font-size: 1rem;">Get Started</a>
        </div>
    </div>
</div>


<!-- Features Start -->
<div class="container-xxl py-5">
    <div class="container-fluid">
        <div class="row g-0 feature-row">
            <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.1s">
                <div class="feature-item border h-100 p-4">
                    <div class="btn-square bg-light rounded-circle mb-4" style="width: 64px; height: 64px;">
                        <img class="img-fluid" src="img/icon/icon-1.png" alt="Icon">
                    </div>
                    <h5 class="mb-3">Being Competitive</h5>
                    <p class="mb-0">Official barangay members possess diverse skills, knowledge, and experience, requiring understanding of duties and dedication to community service.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.3s">
                <div class="feature-item border h-100 p-4">
                    <div class="btn-square bg-light rounded-circle mb-4" style="width: 64px; height: 64px;">
                        <img class="img-fluid" src="img/icon/icon-2.png" alt="Icon">
                    </div>
                    <h5 class="mb-3">Being Professional</h5>
                    <p class="mb-0">Official Barangay officers uphold professional conduct, adhering to ethical standards, norms, and regulations, demonstrating commitment to community service, honesty, and accountability.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.5s">
                <div class="feature-item border h-100 p-4">
                    <div class="btn-square bg-light rounded-circle mb-4" style="width: 64px; height: 64px;">
                        <img class="img-fluid" src="img/icon/icon-3.png" alt="Icon">
                    </div>
                    <h5 class="mb-3">Being Equal</h5>
                    <p class="mb-0">Official Barangay must exhibit fairness and impartiality in interactions with residents, fostering healthy societal relationships and upholding good governance objectives.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.7s">
                <div class="feature-item border h-100 p-4">
                    <div class="btn-square bg-light rounded-circle mb-4" style="width: 64px; height: 64px;">
                        <img class="img-fluid" src="img/icon/icon-4.png" alt="Icon">
                    </div>
                    <h5 class="mb-3">24/7 Support</h5>
                    <p class="mb-0">Official Barangay members offer 24-hour support to residents, addressing community needs efficiently and professionally. They are dedicated to providing courteous and courteous service.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Features End -->
<!-- Announcement and Events  -->
<!-- Announcement -->
<div class="container-fluid ">
    <div class="row">
        <div class="col-lg-7">
          <h1 class="display-12 mb-5 " style="text-align: center;margin-top: 1rem;">Announcement</h1>
          <div class="card mb-3" style=" margin-top: -2rem;" >
              <div class="row g-0">
                <div class="col-md-4">
                  <img src="../pic/nutrisyonmonth.jpg" class="img-fluid rounded-start" alt="...">
              </div>
              <div class="col-md-8">
                  <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                    <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-5">
     <h1 class="display-12 mb-5 " style="text-align: center; margin-top: 1rem; ">Events</h1>
    <div class="card mb-3" style=" margin-top: -2rem;" >
      <div class="row g-0">
       <div class="col-md-2">
          <div class="card-body bg-dark"style="text-align: center;">
            <h5 class="card-title text-white"><b>OCT.</b></h5>
            <h5 class="card-title text-white"><b>25</b></h5>
            <h6 class="card-title text-white">2023</h6>
        </div>
    </div>
      <div class="col-md-10" >
          <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
<!-- will based on database so need ni admin mag enter sa database ng mga nagawa na nila na project and retive also the image -->
<!-- Project Start -->
<div class="container-fluid pt-5 " id="proj">
    <div class="container-fluid">
        <div class="text-center text-md-start pb-5 pb-md-0 wow fadeInUp" data-wow-delay="0.1s"
        style="max-width: 500px;">
        <p class="fs-5 fw-medium text-primary">Our Projects</p>
        <h1 class="display-12 mb-5 ">We've Done Lot's of Awesome Projects</h1>
    </div>
    <div class="owl-carousel project-carousel wow fadeInUp" data-wow-delay="0.1s">
        <div class="project-item mb-5">
            <div class="position-relative">
                <img class="img-fluid img-thumbnail" src="../pic/nutrisyonmonth.jpg" alt=""  style="max-width: 500px;" type="image/svg+xml">
                <div class="project-overlay">
                    <a class="btn btn-lg-square btn-light rounded-circle m-1" href="img/project-1.jpg"
                    data-lightbox="project"><i class="fa fa-eye"></i></a>
                    <a class="btn btn-lg-square btn-light rounded-circle m-1" href=""><i
                        class="fa fa-link"></i></a>
                    </div>
                </div>
                <div class="p-4" >
                    <a class="d-block h5" href="">Nutrition Month</a>
                    <span>Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem</span>
                </div>
            </div>
            <div class="project-item mb-5">
                <div class="position-relative">
                    <img class="img-fluid" src="../pic/brgy_members1.jpg" alt="">
                    <div class="project-overlay">
                        <a class="btn btn-lg-square btn-light rounded-circle m-1" href="img/project-2.jpg"
                        data-lightbox="project"><i class="fa fa-eye"></i></a>
                        <a class="btn btn-lg-square btn-light rounded-circle m-1" href=""><i
                            class="fa fa-link"></i></a>
                        </div>
                    </div>
                    <div class="p-4" >
                        <a class="d-block h5" href="">Marketing Content Strategy</a>
                        <span>Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem</span>
                    </div>
                </div>
                <div class="project-item mb-5">
                    <div class="position-relative">
                        <img class="img-fluid" src="img/project-3.jpg" alt="">
                        <div class="project-overlay">
                            <a class="btn btn-lg-square btn-light rounded-circle m-1" href="img/project-3.jpg"
                            data-lightbox="project"><i class="fa fa-eye"></i></a>
                            <a class="btn btn-lg-square btn-light rounded-circle m-1" href=""><i
                                class="fa fa-link"></i></a>
                            </div>
                        </div>
                        <div class="p-4" >
                            <a class="d-block h5" href="">Business Target Market</a>
                            <span>Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem</span>
                        </div>
                    </div>
                    <div class="project-item mb-5">
                        <div class="position-relative">
                            <img class="img-fluid" src="img/project-4.jpg" alt="">
                            <div class="project-overlay">
                                <a class="btn btn-lg-square btn-light rounded-circle m-1" href="img/project-4.jpg"
                                data-lightbox="project"><i class="fa fa-eye"></i></a>
                                <a class="btn btn-lg-square btn-light rounded-circle m-1" href=""><i
                                    class="fa fa-link"></i></a>
                                </div>
                            </div>
                            <div class="p-4">
                                <a class="d-block h5" href="">Social Marketing Strategy</a>
                                <span>Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Project End -->
             <!-- Team Start -->

        <!-- Footer Start -->
        <div class="container-fluid bg-dark footer mt-5 py-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
                        <h4 class="text-white mb-4">Our Office</h4>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Barangay 781 Zone 85 Sta. Ana Manila City</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+012 8856 9560</p>
                        <p class="mb-2" style="font-size: 13px;"><i class="fa fa-envelope me-3" style="font-size: 19px;"></i>barangay781.2023@gmail.com</p>
                        <div class="d-flex pt-3">
                            <a class="btn btn-square btn-light rounded-circle me-2" href="barangay781.2023@gmail.com"><i
                                class="fab fa-google"></i></a>
                                <a class="btn btn-square btn-light rounded-circle me-2" href="https://www.facebook.com/profile.php?id=100089497350963"><i
                                    class="fab fa-facebook-f"></i></a>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6">
                                        <h4 class="text-white mb-4">Quick Links</h4>
                                        <a class="btn btn-link" href="about.php">About Us</a>
                                        <a class="btn btn-link" href="residentsreports.php">Contact Us</a>
                                        <a class="btn btn-link" href="#proj">Our Projects</a>
                                        <a class="btn btn-link" href="">Terms & Condition</a><!-- TBF -->
                                    </div>
                                    <div class="col-lg-3 col-md-6">
                                        <h4 class="text-white mb-4">Business Hours</h4>
                                        <p class="mb-1">Monday - Friday</p>
                                        <h6 class="text-light">09:00 am - 07:00 pm</h6>
                                        <p class="mb-1">Saturday</p>
                                        <h6 class="text-light">09:00 am - 12:00 pm</h6>
                                        <p class="mb-1">Sunday</p>
                                        <h6 class="text-light">Closed</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Footer End -->


                        <!-- Copyright Start -->
                        <div class="container-fluid copyright py-4">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                                        &copy; <a class="fw-medium text-light" href="#">J.Rizz&Co.</a>, All Right Reserved.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Copyright End -->


                        <!-- Back to Top -->
                        <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i
                            class="bi bi-arrow-up"></i></a>


                            <!-- JavaScript Libraries -->
                            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
                            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
                            <script src="lib/wow/wow.min.js"></script>
                            <script src="lib/easing/easing.min.js"></script>
                            <script src="lib/waypoints/waypoints.min.js"></script>
                            <script src="lib/owlcarousel/owl.carousel.min.js"></script>
                            <script src="lib/lightbox/js/lightbox.min.js"></script>

                            <!-- Template Javascript -->
                            <script src="js/main.js"></script>
                        </body>

                        </html>