<?php
require_once('tcpdf/tcpdf.php');

$name = isset($_POST['name']) ? $_POST['name'] : '';
$age = isset($_POST['age']) ? $_POST['age'] : '';
$date = isset($_POST['date']) ? $_POST['date'] : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';

// Path to the PDF template
$templatePath = 'cert/indigency.pdf';  // Replace with your actual path to the template
$imagePath = 'cert/indigency.jpg';  // Path to the image converted from the template

// Convert PDF template to image using GD (requires Ghostscript)
if (!file_exists($imagePath)) {
    exec("gs -sDEVICE=jpeg -sOutputFile={$imagePath} -r300 {$templatePath}");
}

class PDF extends TCPDF {
    function Header() {
        // Add your header content here if needed
    }

    function Footer() {
        // Add your footer content here if needed
    }
}

// Create an instance of TCPDF
$pdf = new PDF();
$pdf->AddPage();

// Set the position for the dynamic data
$xName = 85;
$yName = 63;

$xdate = 100;
$ydate = 120;

// Add the image as a background
$pdf->Image($imagePath, 0, 0, 210);

// Use the built-in "helvetica" font
$pdf->SetFont('helvetica', '', 12);

// Place dynamic data at specific coordinates on the template
$pdf->SetXY($xName, $yName);
$pdf->writeHTMLCell(110, 0, $xName, $yName, "This is to certify that <b><u><i>{$name}</i></u></b>, <b><u><i>{$age}</i></u></b> years old, is a registered voter and bonafide resident of this barangay with postal address <b><u><i>{$address}</i></u></b>. He/she is one of the indigents of this Barangay.<br><br>This certification is being issued upon the request of the bearer for the reason stated below and for whatever legal purpose it may serve.", 0, 1, false, true, 'J');



// Output the PDF
$pdf->Output($name . '-' . 'Certificate.pdf', 'D');
?>
