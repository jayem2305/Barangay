<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>781 Zone 85</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../pic/brgy_logo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
    href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&family=Roboto:wght@500;700&display=swap"
    rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
    <path fill-rule="evenodd" d="M3.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L9.293 8 3.646 2.354a.5.5 0 0 1 0-.708z"/>
    <path fill-rule="evenodd" d="M7.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L13.293 8 7.646 2.354a.5.5 0 0 1 0-.708z"/>
</svg>
<path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
<path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
</svg>
<path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5h-2z"/>
<path d="M4.5 12.5A.5.5 0 0 1 5 12h3a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5zm0-2A.5.5 0 0 1 5 10h6a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5zm1.639-3.708 1.33.886 1.854-1.855a.25.25 0 0 1 .289-.047l1.888.974V8.5a.5.5 0 0 1-.5.5H5a.5.5 0 0 1-.5-.5V8s1.54-1.274 1.639-1.208zM6.25 6a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5z"/>
</svg>
<!-- Libraries Stylesheet -->
<link href="lib/animate/animate.min.css" rel="stylesheet">
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="../css/dataTables.min.css" rel="stylesheet">
<!-- Template Stylesheet -->
<link href="css/style.css" rel="stylesheet">
<style type="text/css">
 #hero {
  background-repeat: no-repeat;
  animation: carousel 1000s linear infinite;
}

@keyframes carousel {
  0%, 100% {
    background-position: 0 0;
}
25% {
    background-position: 100% 0;
}
50% {
    background-position: 200% 0;
}
75% {
    background-position: 300% 0;
}
}

.custom-h6 {

    margin-bottom: 0; /* Lessen margin bottom */
    margin-left: -1rem;
}
.custom-h6 {

    margin-bottom: 0; /* Lessen margin bottom */
    margin-left: -1rem;
}
</style>
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner"class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
    </div>
    <!-- Spinner End -->
    <!-- Navbar Start -->
    <div class="container-fluid bg-dark sticky-top">
        <div class="container-fluid bg-transparent">
            <nav class="navbar navbar-expand-lg bg-transparent navbar-light p-lg-0">
                <button type="button" class="navbar-toggler me-0" data-bs-toggle="collapse"
                data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ">
                    <a href="index.php" class="nav-item nav-link text-white " >Home</a>
                    <a href="contentmanager.php" class="nav-item nav-link text-white" >Content Manager</a>
                    <a href="certificate.php" class="nav-item nav-link active">Certificates</a>
                    <a href="residence.php" class="nav-item nav-link text-white">Residences</a>
                    <a href="residentreports.php" class="nav-item nav-link text-white">Residents Reports</a>
                </div>
                <div class="ms-auto d-none d-lg-block">
                   <a href="../login/index.php" class="btn btn-danger rounded-pill py-2 px-3">Log Out</a>
               </div> 
           </div>
       </nav>
   </div>
</div>
<!-- Navbar End -->

<div class="container-fluid px-0 mb-5">
    <section id="hero" class="d-flex align-items-center" style=" max-width: 100%;
    height: auto;
    height: calc(50vh - 50px);
    background: url('../pic/whole.png') top center;
    background-size: cover;
    opacity: .8;
    position: relative;">
    <div class="container position-relative" data-aos="fade-up" data-aos-delay="500">
        <h1 style="font-size: 5rem;">CONTENT MANAGER</h1>
    </div>
</section>
</div>


<!-- Features Start -->
<!-- monitoring start -->
<div class="col-lg-12" >
    <div class="card w-100 mb-3">
      <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <h3>History and Monitoring of Certificate</h3>
                <div class="overflow-auto row" style="max-height: 40rem;">
                    <table class="table table-hover"  id="mytable">
                      <thead>
                        <tr>
                          <th scope="col">Control Number</th>
                          <th scope="col">Name</th>
                          <th scope="col">Date</th>
                          <th scope="col">Address</th>
                          <th scope="col">Certificate</th>
                          <th scope="col">Purpose</th>
                          <th scope="col">Remarks</th>
                          <th scope="col">Action</th>
                      </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row">A12138658</th>
                      <td>Mark</td>
                      <td>10/29/23</td>
                      <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                      <td>Barangay Indigency</td>
                      <td>Philhealth ID</td>
                      <td class="text-warning">...In process</td>
                      <td><button type="button" class="btn btn-success">Approve</button><button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">Decline</button></td>
                  </tr>
                  <tr>
                   <th scope="row">A12138658</th>
                   <td>Mark</td>
                   <td>10/02/23</td>
                   <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                   <td>Barangay Indigency</td>
                   <td>Philhealth ID</td>
                   <td class="text-warning">...In process</td>
                   <td><button type="button" class="btn btn-success">Approve</button><button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">Decline</button></td>
               </tr>
               <tr>
                  <th scope="row">A12138658</th>
                  <td>Mark</td>
                  <td>10/20/23</td>
                  <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                  <td>Barangay Indigency</td>
                  <td>Philhealth ID</td>
                  <td class="text-warning">...In process</td>
                  <td><button type="button" class="btn btn-success">Approve</button><button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">Decline</button></td>
              </tr>
              <tr>
                  <th scope="row">A12138658</th>
                  <td>Mark</td>
                  <td>10/31/23</td>
                  <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                  <td>Barangay Indigency</td>
                  <td>Philhealth ID</td>
                  <td class="text-warning">...In process</td>
                  <td><button type="button" class="btn btn-success">Approve</button><button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">Decline</button></td>
              </tr>
              <tr>
                  <th scope="row">A12138658</th>
                  <td>Mark</td>
                  <td>10/31/23</td>
                  <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                  <td>Barangay Indigency</td>
                  <td>Philhealth ID</td>
                  <td class="text-warning">...In process</td>
                  <td><button type="button" class="btn btn-success">Approve</button><button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">Decline</button></td>
              </tr>
          </tbody>
      </table>
  </div>
</div>
</div>
</div>
</div>
</div>
<!-- monitoring end -->
<!-- history and monitoring of my request start -->
<div class="col-lg-12" >
    <div class="card w-100 mb-3">
      <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <div class="overflow-auto row" style="max-height: 40rem;">
                    <table class="table table-hover" id="mytableforprocess">
                      <thead>
                        <tr>
                          <th scope="col">Control Number</th>
                          <th scope="col">Name</th>
                          <th scope="col">Date</th>
                          <th scope="col">Address</th>
                          <th scope="col">Certificate</th>
                          <th scope="col">Purpose</th>
                          <th scope="col">Remarks</th>
                      </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row">A12138658</th>
                      <td>Mark</td>
                      <td>10/29/23</td>
                      <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                      <td>Barangay Indigency</td>
                      <td>Philhealth ID</td>
                      <td><a href=""data-bs-toggle="modal" data-bs-target="#declined" ><h5 class="text-danger" ><u>Declined !</u></h5></a></td>
                  </tr>
                  <tr>
                   <th scope="row">A12138658</th>
                   <td>Mark</td>
                   <td>10/02/23</td>
                   <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                   <td>Barangay Indigency</td>
                   <td>Philhealth ID</td>
                   <td ><h5 class="text-success" >Claimed!</h5></td>
               </tr>
               <tr>
                  <th scope="row">A12138658</th>
                  <td>Mark</td>
                  <td>10/20/23</td>
                  <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                  <td>Barangay Indigency</td>
                  <td>Philhealth ID</td>
                  <td><span class="btn btn-danger" id="cancelButton" onclick="changeButtonTextcancel()">Cancel Request</span></td>
              </tr>
              <tr>
                  <th scope="row">A12138658</th>
                  <td>Mark</td>
                  <td>10/31/23</td>
                  <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                  <td>Barangay Indigency</td>
                  <td>Philhealth ID</td>
                  <td><span class="btn btn-success" id="claimButton" onclick="changeButtonText()">Ready To Claim</span></td>
              </tr>
              <tr>
                  <th scope="row">A12138658</th>
                  <td>Mark</td>
                  <td>10/31/23</td>
                  <td>2036 Int.6 Pilar Estate St. Sta ana manila City</td>
                  <td>Barangay Indigency</td>
                  <td>Philhealth ID</td>
                  <td ><h5 class="text-danger" >Cancelled</h5></td>
              </tr>
          </tbody>
      </table>
  </div>
</div>
</div>
</div>
</div>
</div>
<!-- history and monitoring of my request end -->
<!-- satistic report start-->
<div class="card">
  <div class="card-body">
    <div class="row">
        <div class="col-lg-6">
          <h3>Statistical Reports of Requested Certificates</h3>
      </div>
      <div class="col-lg-6">
       <select class="form-select form-select-lg mb-3" aria-label="Large select example" id="yearSelect">
          <option selected>Select a Year</option>
      </select>
  </div>
</div>
  <div class="col-lg-12">
   <table class="table table-hover" style="text-align:center;" id="tableidstatistic">
      <thead>
        <tr>
          <th scope="col">Monnth</th>
          <th scope="col">Week 1</th>
          <th scope="col">Week 2</th>
          <th scope="col">Week 3</th>
          <th scope="col">week 4</th>
          <th scope="col">Totals</th>
      </tr>
  </thead>
  <tbody>
    <tr>
        <th scope="row">January</th>
        <td>1,000</td>
        <td></td>
        <td></td>
        <td></td>
        <td>1,000</td>
    </tr>
    <tr>
        <th scope="row">February</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
      <th scope="row">March</th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
  </tr>
  <tr>
      <th scope="row">April</th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
  </tr>
  <th scope="row">May</th>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
</tr>
<tr>
    <th scope="row">June</th>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr>
  <th scope="row">July</th>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
</tr>
<tr>
  <th scope="row">August</th>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
</tr>
<tr>
  <th scope="row">September</th>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
</tr>
<tr>
   <th scope="row">October</th>
   <td></td>
   <td></td>
   <td></td>
   <td></td>
   <td></td>
</tr>
<tr>
  <th scope="row">November</th>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
</tr>
<tr>
  <th scope="row">DECMBER</th>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
</tr>
<tr class="bg-primary text-white">
  <th scope="row">YEARLY</th>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td>1,000</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<!-- statistic report end -->
<!-- Features End -->

<!-- Footer Start -->
<div class="container-fluid bg-dark footer mt-5 py-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-3 col-md-6">
                <h4 class="text-white mb-4">Our Office</h4>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Barangay 781 Zone 85 Sta. Ana Manila City</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+012 8856 9560</p>
                <p class="mb-2" style="font-size: 13px;"><i class="fa fa-envelope me-3" style="font-size: 19px;"></i>barangay781.2023@gmail.com</p>
                <div class="d-flex pt-3">
                    <a class="btn btn-square btn-light rounded-circle me-2" href="barangay781.2023@gmail.com"><i
                        class="fab fa-google"></i></a>
                        <a class="btn btn-square btn-light rounded-circle me-2" href="https://www.facebook.com/profile.php?id=100089497350963"><i
                            class="fab fa-facebook-f"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="text-white mb-4">Quick Links</h4>
                        <a class="btn btn-link" href="about.php">About Us</a>
                        <a class="btn btn-link" href="residentsreports.php">Contact Us</a>
                        <a class="btn btn-link" href="#proj">Our Projects</a>
                        <a class="btn btn-link" href="">Terms & Condition</a><!-- TBF -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="text-white mb-4">Business Hours</h4>
                        <p class="mb-1">Monday - Friday</p>
                        <h6 class="text-light">09:00 am - 07:00 pm</h6>
                        <p class="mb-1">Saturday</p>
                        <h6 class="text-light">09:00 am - 12:00 pm</h6>
                        <p class="mb-1">Sunday</p>
                        <h6 class="text-light">Closed</h6>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->


        <!-- Copyright Start -->
        <div class="container-fluid copyright py-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="fw-medium text-light" href="#">J.Rizz&Co.</a>, All Right Reserved.
                    </div>
                </div>
            </div>
        </div>
        <!-- Copyright End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i
            class="bi bi-arrow-up"></i></a>


            <!-- JavaScript Libraries -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
            <script src="lib/wow/wow.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="crossorigin="anonymous"></script>
            <script src="../js/jquery/dataTables.min.js"></script>
            <script src="lib/easing/easing.min.js"></script>
            <script src="lib/waypoints/waypoints.min.js"></script>
            <script src="lib/owlcarousel/owl.carousel.min.js"></script>
            <script src="lib/lightbox/js/lightbox.min.js"></script>

            <!-- Template Javascript -->
            <script src="js/main.js"></script>
            <script>
                $('input[name="enrol"]').change(function() {
                  if ($('#yesenrol').is(':checked')) {
                    $('#School').prop('disabled', false);
                    $('#COR').prop('disabled', false);
                    $('#Level').prop('disabled', false);
                } else {
                    if ($('#noenrol').is(':checked')) {
                     $('#School').prop('disabled', true);
                     $('#COR').prop('disabled', true);
                     $('#Level').prop('disabled', true);
                 }
             }
         });
                $('input[name="tenant"]').change(function() {
                  if ($('#yestenant').is(':checked')) {
                    $('#landlord').prop('disabled', false);
                } else {
                    if ($('#notenant').is(':checked')) {
                     $('#landlord').prop('disabled', true);
                 }
             }
         });
                const passwordInput = document.getElementById('password');
                const toggleButton = document.getElementById('togglePassword');
                const eyeIcon = document.getElementById('eyeIcon');
                let isPasswordVisible = false;

                toggleButton.addEventListener('click', () => {
                    if (isPasswordVisible) {
                        passwordInput.type = 'password';
                        eyeIcon.classList.remove('bi-eye');
                        eyeIcon.classList.add('bi-eye-slash');
                    } else {
                        passwordInput.type = 'text';
                        eyeIcon.classList.remove('bi-eye-slash');
                        eyeIcon.classList.add('bi-eye');
                    }
                    isPasswordVisible = !isPasswordVisible;
                });

            </script>
            <script type="text/javascript">
              $(document).ready(function(){
                  $('#mytable').DataTable();
              });
              $(document).ready(function(){
                  $('#mytableforprocess').DataTable();
              });
              $(document).ready(function(){
                  $('#tableidstatistic').DataTable();
              });
          </script>
          <script>
              const selectElement = document.querySelector(".form-select");

  // Get the current year
              const currentYear = new Date().getFullYear();

  // Generate and add year options to the select element
              for (let year = 2000; year <= currentYear; year++) {
                const option = document.createElement("option");
                option.value = year;
                option.textContent = year;
                selectElement.appendChild(option);
            }
            function changeButtonText() {
                const button = document.getElementById("claimButton");

                if (button.textContent === "Ready To Claim") {
                  button.textContent = "Claimed";
                  button.value = "ready to claim";
              } else if (button.textContent === "Claimed") {
                  button.innerHTML = '<h5 class="text-success custom-h6">Claimed!</h5>';
        button.classList.remove("btn-success"); // Remove the success class
        button.value = "claimed"; 
    }
}
function changeButtonTextcancel() {
    const button = document.getElementById("cancelButton");

    if (button.textContent === "Cancel Request") {
       button.innerHTML = '<h5 class="text-danger custom-h6">Cancelled</h5>';
        button.classList.remove("btn-danger"); // Remove the success class
        button.value = "cancel"; 
    } 
}
</script>
<!-- Modal archive -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Declined</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <div class="row">
            <div class=" col-md-12">
                <h6>To: Mark</h6>
            </div>
            <div class=" col-md-12">
               <div class="form-floating">
                  <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                  <label for="floatingTextarea">Why is it Decline ?</label>
              </div>
          </div>
      </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    <button type="button" class="btn btn-primary">Submit</button>
</div>
</div>
</div>
</div>
<!-- Modal declined -->
<div class="modal fade" id="declined" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Reason of Decline Document</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <h6>To: Mark</h6>
        <p>We Apologize because it was declined due to:<br>
        1.Incomplete requirements</p>
    </div>
</div>
</div>
</div>
</body>


</html>